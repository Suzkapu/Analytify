import {test, expect} from './fixtures';
import {mockSpotify, seedAuthenticatedBrowser, expectNoBlockingAxeViolations} from './helpers/authenticated-browser';
import {observeNativeTransitions, expectNativeTransitionsSettled} from './helpers/native-transitions';
import {writeFile} from 'node:fs/promises';

for (const motion of ['no-preference', 'reduce'] as const) {
  test(`Friends native workflow and responsive recovery (${motion})`, async ({page}, info) => {
    await observeNativeTransitions(page);
    await page.emulateMedia({reducedMotion: motion}); await mockSpotify(page);
    const actor = '11111111-1111-4111-8111-111111111111';
    const friend = {userId: '22222222-2222-4222-8222-222222222222', displayName: 'Suzkapu', imageUrl: '', connectedAt: '2026-10-11', connectionVersion: '33333333-3333-4333-8333-333333333333'};
    let friends = [friend];
    let requests = [{requestId: '44444444-4444-4444-8444-444444444444', inviterUserId: friend.userId, displayName: 'Paulzgi', imageUrl: '', createdAt: '2026-10-11'}];
    let invitations: {id: string; status: string; createdAt: string}[] = [];
    const writes: {name: string; body: Record<string, unknown>}[] = [];
    const unexpected: string[] = []; const runtimeErrors: string[] = [];
    page.on('pageerror', error => runtimeErrors.push(error.message));
    await page.route('http://127.0.0.1:54321/**', async route => {
      const path = new URL(route.request().url()).pathname;
      if (path === '/auth/v1/user') return route.fulfill({json: {id: actor, aud: 'authenticated', role: 'authenticated', app_metadata: {}, user_metadata: {}}});
      if (path === '/rest/v1/users') return route.fulfill({json: null});
      const name = path.split('/').at(-1)!;
      if (name === 'get_public_site_settings') return route.fulfill({json: {}});
      if (name === 'is_app_admin') return route.fulfill({json: false});
      if (name === 'list_friends') return route.fulfill({json: friends});
      if (name === 'list_friend_requests') return route.fulfill({json: requests});
      if (name === 'list_friend_invitations') return route.fulfill({json: invitations});
      const body = route.request().postDataJSON();
      if (name === 'respond_friend_request') {
        writes.push({name, body}); requests = [];
        return route.fulfill({json: {id: body.p_invitation_id, status: body.p_accept ? 'accepted' : 'declined', isConnected: body.p_accept}});
      }
      if (name === 'create_friend_invitation') {
        writes.push({name, body});
        const invitation = {id: '55555555-5555-4555-8555-555555555555', status: 'pending', createdAt: '2026-10-12'};
        invitations = [invitation]; return route.fulfill({json: invitation});
      }
      if (name === 'revoke_friend_invitation') {
        writes.push({name, body}); invitations = []; return route.fulfill({json: null});
      }
      if (name === 'remove_friend') {
        writes.push({name, body}); friends = []; return route.fulfill({json: null});
      }
      unexpected.push(`${route.request().method()} ${path}`); return route.abort('blockedbyclient');
    });
    await seedAuthenticatedBrowser(page, {cloudIdentity: true});
    await page.evaluate(actorId => {
      const exp = Math.floor(Date.now() / 1000) + 3600;
      const encode = (value: object) => btoa(JSON.stringify(value)).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
      localStorage.setItem('sb-127-auth-token', JSON.stringify({access_token: `${encode({alg: 'HS256', typ: 'JWT'})}.${encode({sub: actorId, role: 'authenticated', exp})}.fixture-signature`, refresh_token: 'synthetic-refresh-only', token_type: 'bearer', expires_at: exp, expires_in: 3600, user: {id: actorId, aud: 'authenticated', role: 'authenticated', app_metadata: {}, user_metadata: {}}}));
    }, actor);
    await page.goto('/new/friends');
    const panel = page.locator('v2-friends-page');
    await expect(panel.getByRole('heading', {name: 'Your friends', exact: true})).toBeVisible();
    await expect(panel.getByText('Friend request from Paulzgi', {exact: true})).toBeVisible();
    await expectNativeTransitionsSettled(page);
    await expectNoBlockingAxeViolations(page);
    await panel.getByRole('button', {name: 'Decline', exact: true}).press('Enter');
    await expect(panel.getByText('Friend request from Paulzgi', {exact: true})).toHaveCount(0);
    expect(writes).toEqual([{name: 'respond_friend_request', body: {p_invitation_id: '44444444-4444-4444-8444-444444444444', p_accept: false}}]);
    const manage = panel.getByRole('button', {name: 'Manage friend Suzkapu'});
    await manage.press('Enter'); await panel.getByRole('menuitem', {name: 'Remove friend'}).press('Enter');
    const dialog = panel.getByRole('dialog', {name: 'Remove Suzkapu?'});
    await expect(dialog).toBeVisible();
    await expect(dialog.getByRole('button')).toHaveText(['Remove friend', 'Cancel']);
    await expect(dialog.getByRole('button', {name: 'Remove friend', exact: true})).toBeFocused();
    await page.keyboard.press('Shift+Tab'); await expect(dialog.getByRole('button', {name: 'Cancel', exact: true})).toBeFocused();
    const geometry = [];
    for (const height of [480, 1000]) for (const width of [320, 360, 390, 767, 768, 1024, 1440, 1920]) {
      await page.setViewportSize({width, height});
      await expect(dialog).toBeVisible();
      const sample = await dialog.evaluate(element => {
        const rect = element.getBoundingClientRect();
        return {width: innerWidth, height: innerHeight, scrollWidth: document.documentElement.scrollWidth, x: rect.x, y: rect.y, right: rect.right, bottom: rect.bottom,
          backdropFilter: getComputedStyle(document.querySelector('.confirmation-backdrop')!).backdropFilter};
      });
      expect(sample.scrollWidth).toBeLessThanOrEqual(width);
      expect(sample.x).toBeGreaterThanOrEqual(0); expect(sample.right).toBeLessThanOrEqual(width);
      expect(sample.y).toBeGreaterThanOrEqual(0); expect(sample.bottom).toBeLessThanOrEqual(height);
      expect(sample.backdropFilter).toBe('blur(12px)'); geometry.push(sample);
    }
    await page.keyboard.press('Escape'); await expect(dialog).toHaveCount(0); await expect(manage).toBeFocused();
    expect(writes).toHaveLength(1);
    await panel.getByRole('link', {name: 'Add friend', exact: true}).click();
    const qr = panel.getByRole('img', {name: 'Scan to open this single-person friend invitation'});
    await expect(qr).toBeVisible();
    await expect(qr).toHaveJSProperty('naturalWidth', 176); await expect(qr).toHaveJSProperty('naturalHeight', 176);
    expect(writes[1].name).toBe('create_friend_invitation'); expect(writes[1].body.p_claim_token).toMatch(/^[a-f0-9]{64}$/);
    const expectedUrl = `http://127.0.0.1:4214/new/friends/invite/${writes[1].body.p_claim_token}`;
    await expect(panel.locator('.invitation-url')).toHaveText(expectedUrl);
    await panel.getByRole('link', {name: 'Invitations', exact: true}).click();
    await expect(panel.getByRole('link', {name: 'View link & QR'})).toBeVisible();
    await panel.getByRole('link', {name: 'View link & QR'}).click(); await expect(qr).toBeVisible();
    expect(writes.filter(write => write.name === 'create_friend_invitation')).toHaveLength(1);
    await expectNativeTransitionsSettled(page); await expectNoBlockingAxeViolations(page);
    await page.setViewportSize({width: info.project.name === 'mobile' ? 390 : 1440, height: 900});
    await page.evaluate(() => document.fonts.ready);
    await panel.screenshot({path: info.outputPath('friends-add.png'), animations: 'disabled'});
    await writeFile(info.outputPath('friends-native.json'), JSON.stringify({motion, geometry, writeNames: writes.map(write => write.name), unexpected, runtimeErrors}, null, 2));
    expect(unexpected).toEqual([]); expect(runtimeErrors).toEqual([]);
  });
}
