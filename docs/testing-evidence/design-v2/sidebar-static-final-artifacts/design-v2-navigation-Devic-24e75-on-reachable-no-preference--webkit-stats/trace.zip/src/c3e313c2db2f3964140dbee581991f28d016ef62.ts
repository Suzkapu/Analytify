import {test, expect} from './fixtures';
import {mockSpotify, seedAuthenticatedBrowser, expectNoBlockingAxeViolations} from './helpers/authenticated-browser';
import {observeNativeTransitions, expectNativeTransitionsSettled} from './helpers/native-transitions';
import {writeFile} from 'node:fs/promises';
import type {Page} from '@playwright/test';

// Record ancestor motion as well as tile geometry: a static child can still be
// squeezed by an unintended transition on its shell.
async function navigationRenderState(page: Page) {
  return page.evaluate(() => {
    const measure = () => {
      const shell = document.querySelector('.design-v2')!, sidebar = document.querySelector('.v2-sidebar');
      return {width: innerWidth, mobile: matchMedia('(max-width:760px)').matches,
        shellPadding: getComputedStyle(shell).paddingLeft,
        shellTransition: getComputedStyle(shell).transitionProperty,
        sidebarWidth: sidebar?.getBoundingClientRect().width ?? 0,
        sidebarTransition: sidebar ? getComputedStyle(sidebar).transitionProperty : 'absent',
        animations: [shell, sidebar].filter((node): node is Element => !!node).flatMap(node =>
          node.getAnimations().map(animation => ({state: animation.playState,
            property: 'transitionProperty' in animation ? String(animation.transitionProperty) : 'animation'}))),
        sidebarDisplay: sidebar ? getComputedStyle(sidebar).display : 'absent'};
    };
    return measure();
  });
}

async function prepareNavigation(page: Page, motion: 'no-preference' | 'reduce') {
  await observeNativeTransitions(page); await page.emulateMedia({reducedMotion: motion}); await mockSpotify(page);
  const unexpected: string[] = [], errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.route('http://127.0.0.1:54321/**', route => {
    const name = new URL(route.request().url()).pathname.split('/').at(-1);
    if (name === 'get_public_site_settings') return route.fulfill({json: {}});
    if (name === 'is_app_admin') return route.fulfill({json: false});
    unexpected.push(route.request().url()); return route.abort('blockedbyclient');
  });
  await seedAuthenticatedBrowser(page);
  return {unexpected, errors};
}

for (const motion of ['no-preference', 'reduce'] as const) {
  test(`Desktop sidebar keeps geometry and mobile independence (${motion})`, async ({page}, info) => {
    const {unexpected, errors} = await prepareNavigation(page, motion);
    await page.setViewportSize({width: 1440, height: 900});
    await page.goto('/new/settings/navigation');
    await expect(page.getByRole('status').filter({hasText: /^3 of 5 shortcuts selected$/})).toBeVisible();
    const sidebar = page.getByRole('complementary', {name: 'Desktop sidebar'});
    if (motion === 'reduce') {
      await expect(page.locator('.design-v2')).toHaveCSS('transition-property', 'none');
      await expect(sidebar).toHaveCSS('transition-property', 'none');
    }
    const geometry = [];
    for (const width of [761, 1024, 1440, 1920]) {
      for (const height of [480, 900]) {
        await page.setViewportSize({width, height});
        for (const compact of [false, true]) {
          const toggle = sidebar.getByRole('button', {name: compact ? 'Collapse navigation sidebar' : 'Expand navigation sidebar', exact: true});
          if (await toggle.count()) await toggle.press('Enter');
          const currentToggle = sidebar.getByRole('button', {name: compact ? 'Expand navigation sidebar' : 'Collapse navigation sidebar', exact: true});
          await expect(currentToggle).toHaveAttribute('aria-expanded', compact ? 'false' : 'true');
          const responsiveFrame = await navigationRenderState(page);
          for (const name of ['Playlists', 'Stats', 'History', 'Friends', 'Song Leagues', 'Private Sharing', 'Compare playlists', 'Settings']) {
            await expect(sidebar.getByRole('link', {name, exact: true})).toHaveCount(1);
          }
          const sample = await sidebar.evaluate(element => {
            const box = element.getBoundingClientRect(), panel = element.querySelector('.navigation-panel')!;
            const profile = element.querySelector('.drawer-profile')!.getBoundingClientRect();
            const group = element.querySelector('.navigation-groups')!;
            const icon = element.querySelector('.drawer-link i')!.getBoundingClientRect();
            const logo = element.querySelector('.drawer-brand img')!.getBoundingClientRect();
            const surface = getComputedStyle(panel, '::before');
            return {width: innerWidth, height: innerHeight, sidebarWidth: box.width, sidebarHeight: box.height, x: box.x, y: box.y,
              profileBottom: profile.bottom, profileHeight: profile.height, profileWidth: profile.width,
              iconCenter: icon.x + icon.width / 2, logoCenter: logo.x + logo.width / 2,
              listHeight: group.clientHeight, listScroll: group.scrollHeight, listOverflow: getComputedStyle(group).overflowY,
              surfaceWidth: Number.parseFloat(surface.width), surfaceTop: surface.top,
              contentLeft: document.querySelector('main')!.getBoundingClientRect().left,
              overflow: document.documentElement.scrollWidth - innerWidth};
          });
          expect(sample.sidebarWidth).toBe(compact ? 98 : 256); expect(sample.sidebarHeight).toBe(height);
          expect(sample.x).toBe(0); expect(sample.y).toBe(0); expect(sample.profileHeight).toBe(72);
          expect(sample.profileWidth).toBe(compact ? 48 : 206); expect(sample.profileBottom).toBe(height - 25);
          expect(sample.iconCenter).toBe(49); expect(sample.logoCenter).toBe(49);
          expect(sample.surfaceWidth).toBe(compact ? 82 : 240); expect(sample.surfaceTop).toBe('10px');
          expect(sample.contentLeft).toBeGreaterThanOrEqual(sample.sidebarWidth); expect(sample.overflow).toBeLessThanOrEqual(1);
          expect(sample.listOverflow).toBe('auto'); if (height === 480) expect(sample.listScroll).toBeGreaterThan(sample.listHeight);
          geometry.push({...sample, compact, responsiveFrame});
        }
      }
    }
    await page.setViewportSize({width: 1440, height: 900});
    await sidebar.getByRole('button', {name: 'Expand navigation sidebar', exact: true}).press('Enter');
    await sidebar.screenshot({path: info.outputPath('sidebar-expanded.png'), animations: 'disabled'});
    await sidebar.getByRole('button', {name: 'Collapse navigation sidebar', exact: true}).press('Space');
    await sidebar.screenshot({path: info.outputPath('sidebar-compact.png'), animations: 'disabled'});
    await expectNoBlockingAxeViolations(page);
    await page.setViewportSize({width: 390, height: 900}); await expect(sidebar).toBeHidden();
    await page.getByRole('button', {name: 'Open navigation menu', exact: true}).press('Enter');
    const dialog = page.getByRole('dialog', {name: 'Navigation menu', exact: true});
    await expect(dialog.locator('.drawer-identity')).toBeVisible(); await expect(dialog.locator('.panel--compact')).toHaveCount(0);
    await page.keyboard.press('Escape');
    await page.setViewportSize({width: 1440, height: 900});
    await expect(sidebar.getByRole('button', {name: 'Expand navigation sidebar', exact: true})).toHaveAttribute('aria-expanded', 'false');
    await expectNativeTransitionsSettled(page);
    await writeFile(info.outputPath('sidebar-native.json'), JSON.stringify({motion, geometry, unexpected, errors}, null, 2));
    expect(unexpected).toEqual([]); expect(errors).toEqual([]);
  });
  test(`Device shortcut read and write recovery (${motion})`, async ({page}, info) => {
    await page.addInitScript(() => {
      const faults = {readFailures: 1, writeFailures: 1, failedReads: 0, failedWrites: 0,
        writes: [] as {key: string; value: unknown}[]};
      Object.assign(window, {analytifyPreferenceFaults: faults});
      const get = IDBObjectStore.prototype.get, put = IDBObjectStore.prototype.put;
      IDBObjectStore.prototype.get = function(this: IDBObjectStore, key: IDBValidKey | IDBKeyRange) {
        if (typeof key === 'string' && key.startsWith('design-v2:mobile-shortcuts:') && faults.readFailures > 0) {
          faults.readFailures--; faults.failedReads++;
          throw new DOMException('Synthetic device read failure', 'UnknownError');
        }
        return get.call(this, key);
      };
      IDBObjectStore.prototype.put = function(this: IDBObjectStore, value: unknown, key?: IDBValidKey) {
        const entry = value as {key?: unknown; value?: unknown};
        if (typeof entry?.key === 'string' && entry.key.startsWith('design-v2:mobile-shortcuts:')) {
          faults.writes.push({key: entry.key, value: entry.value});
          if (faults.writeFailures > 0) {
            faults.writeFailures--; faults.failedWrites++;
            throw new DOMException('Synthetic device quota failure', 'QuotaExceededError');
          }
        }
        return key === undefined ? put.call(this, value) : put.call(this, value, key);
      };
    });
    const {unexpected, errors} = await prepareNavigation(page, motion);
    await page.setViewportSize({width: 600, height: 900});
    await page.goto('/new/settings/navigation');
    const panel = page.locator('v2-settings-navigation-preferences');
    const choices = panel.locator('.shortcut-choice');
    const count = panel.getByRole('status').filter({hasText: /^\d of 5 shortcuts selected$/});
    const bar = page.getByRole('navigation', {name: 'Primary navigation', exact: true, includeHidden: true});
    const geometry = [];
    const measureFeedback = async () => {
      const sample = await panel.locator('v2-inline-status section').evaluate(element => {
        const rect = element.getBoundingClientRect();
        const style = (selector: string) => {
          const node = element.querySelector(selector)!, box = node.getBoundingClientRect(), css = getComputedStyle(node);
          return {width: box.width, height: box.height, fontSize: css.fontSize, fontWeight: css.fontWeight, lineHeight: css.lineHeight};
        };
        return {viewport: innerWidth, width: rect.width, height: rect.height, right: rect.right,
          title: style('strong'), description: style('p'), action: style('button'), icon: style('.pi-sync')};
      });
      expect(sample.right).toBeLessThanOrEqual(sample.viewport);
      expect(sample.title).toMatchObject({fontSize: '14px', fontWeight: '600', lineHeight: '20px'});
      expect(sample.description).toMatchObject({fontSize: '14px', fontWeight: '400', lineHeight: '20px'});
      expect(sample.action).toMatchObject({width: 260, height: 48, fontSize: '14px', fontWeight: '600', lineHeight: '20px'});
      expect(sample.icon).toMatchObject({width: 18, height: 18, fontSize: '18px'});
      if (sample.viewport === 600) expect(sample).toMatchObject({width: 576, height: 138});
      geometry.push(sample);
    };
    await expect(panel.getByRole('alert')).toContainText('Navigation preferences could not be loaded');
    await expect(panel.getByRole('button', {name: 'Retry', exact: true}).locator('.pi-sync')).toHaveCount(1);
    await measureFeedback();
    await page.setViewportSize({width: 320, height: 480}); await measureFeedback();
    await page.setViewportSize({width: 600, height: 900});
    await expect(choices).toHaveCount(7);
    for (const button of await choices.all()) await expect(button).toBeDisabled();
    await expect(bar).toHaveCount(0);
    await expectNoBlockingAxeViolations(page);
    await panel.screenshot({path: info.outputPath('navigation-read-error.png'), animations: 'disabled'});
    await panel.getByRole('button', {name: 'Retry', exact: true}).press('Enter');
    await expect(count).toHaveText('3 of 5 shortcuts selected');
    const friends = panel.getByRole('button', {name: 'Friends', exact: true});
    await expect(friends).toBeEnabled(); await friends.press('Enter');
    await expect(panel.getByRole('alert')).toContainText('Navigation changes could not be saved');
    await expect(panel.getByRole('button', {name: 'Retry', exact: true}).locator('.pi-sync')).toHaveCount(1);
    await measureFeedback();
    await page.setViewportSize({width: 320, height: 480}); await measureFeedback();
    await page.setViewportSize({width: 600, height: 900});
    await expect(count).toHaveText('3 of 5 shortcuts selected');
    await expect(friends).toHaveAttribute('aria-pressed', 'false');
    await expect(bar.getByRole('link', {includeHidden: true})).toHaveText(['Playlists', 'Stats', 'History']);
    await expectNoBlockingAxeViolations(page);
    await panel.screenshot({path: info.outputPath('navigation-write-error.png'), animations: 'disabled'});
    await panel.getByRole('button', {name: 'Retry', exact: true}).press('Enter');
    await expect(friends).toBeEnabled();
    await expect(friends).toHaveAttribute('aria-pressed', 'true');
    await expect(count).toHaveText('4 of 5 shortcuts selected');
    await expect(panel.getByRole('alert')).toHaveCount(0);
    const faults = await page.evaluate(() => (window as unknown as {analytifyPreferenceFaults: {
      failedReads: number; failedWrites: number; writes: {key: string; value: unknown}[]
    }}).analytifyPreferenceFaults);
    expect(faults.failedReads).toBe(1); expect(faults.failedWrites).toBe(1);
    expect(faults.writes).toHaveLength(2); expect(faults.writes[1]).toEqual(faults.writes[0]);
    expect(faults.writes[1].value).toBe('["playlists","stats","history","friends"]');
    const saved = await page.evaluate(() => new Promise<{key: string; value: string}[]>((resolve, reject) => {
      const open = indexedDB.open('AnalytifyDB', 4);
      open.onerror = () => reject(open.error);
      open.onsuccess = () => {
        const db = open.result, entries: {key: string; value: string}[] = [];
        const tx = db.transaction(['appData', 'featureData'], 'readonly');
        for (const store of ['appData', 'featureData']) {
          const read = tx.objectStore(store).getAll();
          read.onsuccess = () => entries.push(...read.result.filter(item => item.key.startsWith('design-v2:mobile-shortcuts:')));
        }
        tx.onabort = () => {db.close(); reject(tx.error);};
        tx.oncomplete = () => {db.close(); resolve(entries);};
      };
    }));
    expect(saved).toEqual([faults.writes[1]]);
    await expectNativeTransitionsSettled(page);
    await writeFile(info.outputPath('navigation-recovery.json'), JSON.stringify({motion, geometry, faults, saved, unexpected, errors}, null, 2));
    expect(unexpected).toEqual([]); expect(errors).toEqual([]);
  });
  test(`Device shortcuts persist and keep navigation reachable (${motion})`, async ({page}, info) => {
    const {unexpected, errors} = await prepareNavigation(page, motion);
    await page.goto('/new/settings/navigation');
    const panel = page.locator('v2-settings-navigation-preferences');
    const choice = (name: string) => panel.getByRole('button', {name, exact: true});
    const count = panel.getByRole('status').filter({hasText: /^\d of 5 shortcuts selected$/});
    const bar = page.getByRole('navigation', {name: 'Primary navigation', exact: true, includeHidden: true});
    await expect(panel.getByRole('heading', {name: 'Bottom navigation'})).toBeVisible();
    await expect(count).toHaveText('3 of 5 shortcuts selected');
    await expect(bar.getByRole('link', {includeHidden: true})).toHaveText(['Playlists', 'Stats', 'History']);
    await choice('Friends').press('Enter');
    await expect(count).toHaveText('4 of 5 shortcuts selected');
    await expect(choice('Song Leagues')).toBeEnabled();
    await choice('Song Leagues').press('Enter');
    await expect(count).toHaveText('5 of 5 shortcuts selected');
    await expect(bar.getByRole('link', {includeHidden: true})).toHaveText(['Playlists', 'Stats', 'History', 'Friends', 'Song Leagues']);
    await expect(bar.locator('a').filter({hasText: 'Friends'})).toHaveAttribute('href', '/new/friends');
    await expect(choice('Private Sharing')).toBeEnabled();
    await choice('Private Sharing').press('Enter');
    await expect(panel.getByText('Five shortcuts selected. Remove one before adding another.', {exact: true})).toBeVisible();
    await expect(choice('Private Sharing')).toHaveAttribute('aria-pressed', 'false');
    const geometry = [];
    for (const height of [480, 1000]) for (const width of [320, 390, 760, 768, 1440]) {
      await page.setViewportSize({width, height});
      const responsiveFrame = await navigationRenderState(page);
      const sample = await panel.evaluate(element => {
        const buttons = [...element.querySelectorAll<HTMLButtonElement>('.shortcut-choice')].map(button => {
          const rect = button.getBoundingClientRect(), css = getComputedStyle(button);
          const icon = button.querySelector('i')!, label = button.querySelector('span')!;
          return {label: label.textContent, left: rect.left, right: rect.right, height: rect.height, fontSize: css.fontSize,
            iconHeight: icon.getBoundingClientRect().height, labelHeight: label.getBoundingClientRect().height,
            padding: css.padding, gap: css.gap, lineHeight: css.lineHeight, width: rect.width,
            transition: css.transitionDuration, transitionProperty: css.transitionProperty};
        });
        const nav = document.querySelector('.v2-mobile-nav')!;
        const rect = nav.getBoundingClientRect();
        return {width: innerWidth, height: innerHeight, scrollWidth: document.documentElement.scrollWidth, buttons,
          bar: {visible: getComputedStyle(nav).display !== 'none', left: rect.left, right: rect.right, bottom: rect.bottom,
            rows: new Set([...nav.querySelectorAll('a')].map(link => Math.round(link.getBoundingClientRect().top))).size}};
      });
      expect(sample.scrollWidth).toBeLessThanOrEqual(width);
      for (const button of sample.buttons) {
        expect(button.left).toBeGreaterThanOrEqual(0); expect(button.right).toBeLessThanOrEqual(width);
        expect(button.height, JSON.stringify({viewport: {width: sample.width, height: sample.height}, button})).toBe(48); expect(button.fontSize).toBe('12px');
        if (motion === 'reduce') expect(button.transitionProperty).toBe('none');
      }
      expect(sample.bar.visible).toBe(width <= 760);
      if (sample.bar.visible) {
        await expect(bar.getByRole('link', {name: 'Friends', exact: true})).toBeVisible();
        expect(sample.bar.rows).toBe(1); expect(sample.bar.left).toBeGreaterThanOrEqual(0);
        expect(sample.bar.right).toBeLessThanOrEqual(width); expect(sample.bar.bottom).toBeLessThanOrEqual(height);
      }
      geometry.push({...sample, responsiveFrame});
    }
    await page.setViewportSize({width: info.project.name === 'mobile' ? 390 : 1440, height: 900});
    await expectNoBlockingAxeViolations(page);
    for (const label of ['Playlists', 'Stats', 'History', 'Friends', 'Song Leagues']) {
      await choice(label).press('Enter');
      await expect(choice(label)).toHaveAttribute('aria-pressed', 'false');
      await expect(choice(label)).toBeEnabled();
    }
    await expect(count).toHaveText('0 of 5 shortcuts selected');
    await expect(bar).toHaveCount(0);
    await page.reload();
    await expect(count).toHaveText('0 of 5 shortcuts selected');
    await expect(bar).toHaveCount(0);
    const menu = page.getByRole('button', {name: 'Open navigation menu', exact: true});
    await menu.press('Enter');
    const dialog = page.getByRole('dialog', {name: 'Navigation menu', exact: true});
    await expect(dialog).toBeVisible();
    await dialog.evaluate(element => Promise.all(element.getAnimations().map(animation => animation.finished)));
    for (const label of ['Playlists', 'Stats', 'History', 'Friends', 'Song Leagues', 'Private Sharing', 'Compare playlists', 'Settings']) {
      await expect(dialog.getByRole('link', {name: label, exact: true})).toHaveCount(1);
    }
    const drawerGeometry = [];
    for (const width of [320, 390, 600, 768, 1024, 1440]) {
      for (const height of [480, 900]) {
        await page.setViewportSize({width, height});
        const sample = await dialog.evaluate(element => {
          const box = element.getBoundingClientRect();
          const profile = element.querySelector('.drawer-profile')!.getBoundingClientRect();
          const groups = element.querySelector('.navigation-groups')!;
          return {width: innerWidth, height: innerHeight, x: box.x, y: box.y, drawerWidth: box.width,
            drawerHeight: box.height, profileBottom: profile.bottom, profileHeight: profile.height,
            listBottom: groups.getBoundingClientRect().bottom, listHeight: groups.clientHeight,
            listScroll: groups.scrollHeight, overflow: getComputedStyle(groups).overflowY,
            animation: getComputedStyle(element).animationName};
        });
        expect(sample.x).toBe(0); expect(sample.y).toBe(0);
        expect(sample.drawerWidth).toBe(Math.min(width, 320)); expect(sample.drawerHeight).toBe(height);
        expect(sample.profileBottom).toBe(height - 17); expect(sample.profileHeight).toBe(72);
        expect(sample.listBottom).toBeLessThanOrEqual(sample.profileBottom - 72 - 16);
        expect(sample.overflow).toBe('auto');
        if (height === 480) expect(sample.listScroll).toBeGreaterThan(sample.listHeight);
        if (motion === 'reduce') expect(sample.animation).toBe('none');
        drawerGeometry.push(sample);
      }
    }
    await page.setViewportSize({width: 390, height: 900});
    await dialog.getByRole('link', {name: 'Settings', exact: true}).focus();
    await page.keyboard.press('Tab'); await expect(dialog.getByRole('button', {name: 'Close navigation menu', exact: true})).toBeFocused();
    await page.keyboard.press('Shift+Tab'); await expect(dialog.getByRole('link', {name: 'Settings', exact: true})).toBeFocused();
    await expectNoBlockingAxeViolations(page);
    await dialog.screenshot({path: info.outputPath('navigation-drawer.png'), animations: 'disabled'});
    await page.keyboard.press('Escape'); await expect(dialog).toHaveCount(0); await expect(menu).toBeFocused();
    await choice('Friends').press('Enter');
    await expect(count).toHaveText('1 of 5 shortcuts selected');
    await expect(choice('Friends')).toBeEnabled();
    await expect(panel.getByText('Saving navigation preferences', {exact: true})).toHaveCount(0);
    await page.reload();
    await expect(count).toHaveText('1 of 5 shortcuts selected');
    await expect(bar.getByRole('link', {includeHidden: true})).toHaveText(['Friends']);
    await expectNativeTransitionsSettled(page); await expectNoBlockingAxeViolations(page);
    await page.evaluate(() => document.fonts.ready);
    await panel.screenshot({path: info.outputPath('navigation-selected.png'), animations: 'disabled'});
    await writeFile(info.outputPath('navigation-native.json'), JSON.stringify({motion, geometry, drawerGeometry, unexpected, errors}, null, 2));
    expect(unexpected).toEqual([]); expect(errors).toEqual([]);
  });
}
