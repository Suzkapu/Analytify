import {test, expect} from './fixtures';
import {mockSpotify, seedAuthenticatedBrowser, expectNoBlockingAxeViolations} from './helpers/authenticated-browser';

for (const motion of ['no-preference', 'reduce'] as const) {
  test(`cold Spotify failure differs from empty rankings and offers recovery (${motion})`, async ({page}) => {
    await page.clock.setFixedTime(new Date('2026-10-06T12:00:00Z'));
    await page.emulateMedia({reducedMotion: motion}); await mockSpotify(page); await seedAuthenticatedBrowser(page);
    let failed = true;
    await page.route('https://api.spotify.com/v1/me/top/artists?*', route => failed
      ? route.fulfill({status: 503, headers: {'Retry-After': '0'}, json: {error: {status: 503, message: 'Isolated current Stats failure'}}})
      : route.fulfill({json: {items: [{id: 'recovered-artist', name: 'Recovered artist', genres: ['pop'], images: []}], total: 1}}));
    await page.goto('/new/stats');
    const main = page.getByRole('main');
    await expect(main.getByRole('alert')).toBeVisible({timeout: 12_000});
    await expect(main.getByRole('heading', {name: 'No top songs found', exact: true})).toHaveCount(0);
    await expect(main.locator('v2-stats-ranking-row')).toHaveCount(0);
    failed = false;
    await main.getByRole('button', {name: 'Retry', exact: true}).press('Enter');
    await expect(main.getByText('Test Song', {exact: true})).toBeVisible();
    await expect(main.getByRole('alert')).toHaveCount(0); await expectNoBlockingAxeViolations(page);
  });
}

test('successful empty Spotify responses produce an empty state without a failure alert', async ({page}) => {
  await page.clock.setFixedTime(new Date('2026-10-06T12:00:00Z')); await mockSpotify(page); await seedAuthenticatedBrowser(page);
  await page.route('https://api.spotify.com/v1/me/top/**', route => route.fulfill({json: {items: [], total: 0}}));
  await page.goto('/new/stats'); const main = page.getByRole('main');
  await expect(main.getByRole('heading', {name: 'No top songs found', exact: true})).toBeVisible();
  await expect(main.getByRole('alert')).toHaveCount(0); await expectNoBlockingAxeViolations(page);
});
