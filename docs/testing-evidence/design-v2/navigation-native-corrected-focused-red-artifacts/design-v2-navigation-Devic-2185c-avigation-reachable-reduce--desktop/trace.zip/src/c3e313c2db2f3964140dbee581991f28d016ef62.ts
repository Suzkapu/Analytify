import {test, expect} from './fixtures';
import {mockSpotify, seedAuthenticatedBrowser, expectNoBlockingAxeViolations} from './helpers/authenticated-browser';
import {observeNativeTransitions, expectNativeTransitionsSettled} from './helpers/native-transitions';
import {writeFile} from 'node:fs/promises';

for (const motion of ['no-preference', 'reduce'] as const) {
  test(`Device shortcuts persist and keep navigation reachable (${motion})`, async ({page}, info) => {
    await observeNativeTransitions(page); await page.emulateMedia({reducedMotion: motion}); await mockSpotify(page);
    const unexpected: string[] = [], errors: string[] = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.route('http://127.0.0.1:54321/**', route => {
      const name = new URL(route.request().url()).pathname.split('/').at(-1);
      if (name === 'get_public_site_settings') return route.fulfill({json: {}});
      if (name === 'is_app_admin') return route.fulfill({json: false});
      unexpected.push(route.request().url()); return route.abort('blockedbyclient');
    });
    await seedAuthenticatedBrowser(page);
    await page.goto('/new/settings/navigation');
    const panel = page.locator('v2-settings-navigation-preferences');
    const choice = (name: string) => panel.getByRole('button', {name, exact: true});
    const count = panel.getByRole('status').filter({hasText: /^\d of 5 shortcuts selected$/});
    const bar = page.getByRole('navigation', {name: 'Primary navigation', exact: true, includeHidden: true});
    await expect(panel.getByRole('heading', {name: 'Bottom navigation'})).toBeVisible();
    await expect(count).toHaveText('3 of 5 shortcuts selected');
    await expect(bar.getByRole('link', {includeHidden: true})).toHaveText(['Playlists', 'Stats', 'History']);
    await choice('Friends').press('Enter');
    await expect(count).toHaveText('4 of 5 shortcuts selected');
    await expect(choice('Song Leagues')).toBeEnabled();
    await choice('Song Leagues').press('Enter');
    await expect(count).toHaveText('5 of 5 shortcuts selected');
    await expect(bar.getByRole('link', {includeHidden: true})).toHaveText(['Playlists', 'Stats', 'History', 'Friends', 'Song Leagues']);
    await expect(bar.getByRole('link', {name: 'Friends', exact: true, includeHidden: true})).toHaveAttribute('href', '/new/friends');
    await expect(choice('Private Sharing')).toBeEnabled();
    await choice('Private Sharing').press('Enter');
    await expect(panel.getByText('Five shortcuts selected. Remove one before adding another.', {exact: true})).toBeVisible();
    await expect(choice('Private Sharing')).toHaveAttribute('aria-pressed', 'false');
    const geometry = [];
    for (const height of [480, 1000]) for (const width of [320, 390, 760, 768, 1440]) {
      await page.setViewportSize({width, height});
      const sample = await panel.evaluate(element => {
        const buttons = [...element.querySelectorAll<HTMLButtonElement>('.shortcut-choice')].map(button => {
          const rect = button.getBoundingClientRect(), css = getComputedStyle(button);
          return {left: rect.left, right: rect.right, height: rect.height, fontSize: css.fontSize, transition: css.transitionDuration, transitionProperty: css.transitionProperty};
        });
        const nav = document.querySelector('.v2-mobile-nav')!;
        const rect = nav.getBoundingClientRect();
        return {width: innerWidth, height: innerHeight, scrollWidth: document.documentElement.scrollWidth, buttons,
          bar: {visible: getComputedStyle(nav).display !== 'none', left: rect.left, right: rect.right, bottom: rect.bottom,
            rows: new Set([...nav.querySelectorAll('a')].map(link => Math.round(link.getBoundingClientRect().top))).size}};
      });
      expect(sample.scrollWidth).toBeLessThanOrEqual(width);
      for (const button of sample.buttons) {
        expect(button.left).toBeGreaterThanOrEqual(0); expect(button.right).toBeLessThanOrEqual(width);
        expect(button.height).toBe(48); expect(button.fontSize).toBe('12px');
        if (motion === 'reduce') expect(button.transitionProperty).toBe('none');
      }
      if (sample.bar.visible) {
        expect(sample.bar.rows).toBe(1); expect(sample.bar.left).toBeGreaterThanOrEqual(0);
        expect(sample.bar.right).toBeLessThanOrEqual(width); expect(sample.bar.bottom).toBeLessThanOrEqual(height);
      }
      geometry.push(sample);
    }
    await page.setViewportSize({width: info.project.name === 'mobile' ? 390 : 1440, height: 900});
    await expectNoBlockingAxeViolations(page);
    for (const label of ['Playlists', 'Stats', 'History', 'Friends', 'Song Leagues']) {
      await choice(label).press('Enter');
      await expect(choice(label)).toHaveAttribute('aria-pressed', 'false');
      await expect(choice(label)).toBeEnabled();
    }
    await expect(count).toHaveText('0 of 5 shortcuts selected');
    await expect(bar).toHaveCount(0);
    await page.reload();
    await expect(count).toHaveText('0 of 5 shortcuts selected');
    await expect(bar).toHaveCount(0);
    const menu = page.getByRole('button', {name: 'Open More tools', exact: true});
    await menu.press('Enter');
    const dialog = page.getByRole('dialog', {name: 'More', exact: true});
    await expect(dialog).toBeVisible();
    for (const label of ['Playlists', 'Stats', 'History', 'Friends', 'Song Leagues', 'Private Sharing', 'Compare Room', 'Settings']) {
      await expect(dialog.getByRole('link', {name: label, exact: true})).toHaveCount(1);
    }
    await page.keyboard.press('Escape'); await expect(dialog).toHaveCount(0); await expect(menu).toBeFocused();
    await choice('Friends').press('Enter');
    await expect(count).toHaveText('1 of 5 shortcuts selected');
    await page.reload();
    await expect(count).toHaveText('1 of 5 shortcuts selected');
    await expect(bar.getByRole('link', {includeHidden: true})).toHaveText(['Friends']);
    await expectNativeTransitionsSettled(page); await expectNoBlockingAxeViolations(page);
    await page.evaluate(() => document.fonts.ready);
    await panel.screenshot({path: info.outputPath('navigation-selected.png'), animations: 'disabled'});
    await writeFile(info.outputPath('navigation-native.json'), JSON.stringify({motion, geometry, unexpected, errors}, null, 2));
    expect(unexpected).toEqual([]); expect(errors).toEqual([]);
  });
}
