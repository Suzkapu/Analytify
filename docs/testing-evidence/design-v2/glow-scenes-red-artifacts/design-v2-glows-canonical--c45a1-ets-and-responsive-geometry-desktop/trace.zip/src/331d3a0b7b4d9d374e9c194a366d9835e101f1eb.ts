import {readFile, writeFile} from 'node:fs/promises';
import {expect, test} from './fixtures';
import {mockSpotify, seedAuthenticatedBrowser} from './helpers/authenticated-browser';

for (const [scene, path] of [['Library', 'playlists'], ['Insights', 'history'], ['Social', 'compare-room'], ['League', 'song-league']] as const) {
  test(`canonical glow scene ${scene} preserves native assets and responsive geometry`, async ({page}, info) => {
    const envelope = JSON.parse(await readFile('docs/testing-evidence/design-v2/ambient-route-glow-canonical-geometry.json', 'utf8'));
    const canonical = JSON.parse(envelope.content.find((item: {type: string}) => item.type === 'text').text);
    const errors: string[] = []; const isolatedRequests: string[] = [];
    page.on('pageerror', error => errors.push(error.message));
    // All remote transports are synthetic. Real cloud identity/workflows are
    // separate contracts; this test mounts actual routes to verify their scene.
    await page.route('https://**', route => {isolatedRequests.push(new URL(route.request().url()).origin); return route.fulfill({status: 503, json: {message: 'Isolated glow fixture'}});});
    await mockSpotify(page); await seedAuthenticatedBrowser(page);
    await page.emulateMedia({reducedMotion: 'reduce'});
    await page.goto(`/new/${path}`);
    const ambient = page.locator('app-ambient-background');
    await expect(ambient.locator('.ambient-primary img, .ambient-secondary img')).toHaveCount(2);
    await expect.poll(() => ambient.locator('img').evaluateAll(images => images.every(image => (image as HTMLImageElement).complete && (image as HTMLImageElement).naturalWidth > 0))).toBe(true);
    const geometry: unknown[] = [];
    for (const width of [1440, 1920, 1024, 768, 761, 760, 390, 360, 320]) for (const height of [480, 1000]) {
      await page.setViewportSize({width, height});
      const mobile = width <= 760;
      const reference = canonical.variants.find((variant: {name: string}) => variant.name === `Viewport=${mobile ? 'Mobile' : 'Desktop'}, Scene=${scene}`);
      await expect.poll(() => ambient.locator('img').evaluateAll(images => images.every(image => (image as HTMLImageElement).complete && (image as HTMLImageElement).naturalHeight === (window.innerWidth <= 760 ? 760 : 1050)))).toBe(true);
      const sample = await ambient.evaluate(element => ({background: getComputedStyle(element).backgroundColor, backgroundImage: getComputedStyle(element).backgroundImage,
        glows: ['.ambient-primary', '.ambient-secondary'].map(selector => {
          const glow = element.querySelector(selector)!; const image = glow.querySelector('img')!;
          const rect = image.getBoundingClientRect(); const style = getComputedStyle(glow);
          return {x: rect.x, y: rect.y, width: rect.width, height: rect.height, naturalWidth: image.naturalWidth, naturalHeight: image.naturalHeight,
            asset: new URL(image.currentSrc).pathname.split('/').pop(), alt: image.alt, opacity: style.opacity, backgroundImage: style.backgroundImage};
        })}));
      expect(sample.background).toBe('rgb(7, 11, 9)'); expect(sample.backgroundImage).toBe('none');
      for (const [index, glow] of sample.glows.entries()) {
        const target = reference.glows[index];
        const expectedX = (target.x + target.width / 2) / reference.width * width - target.width / 2;
        const expectedY = (target.y + target.height / 2) / reference.height * height - target.height / 2;
        expect(Math.abs(glow.x - expectedX)).toBeLessThan(.03); expect(Math.abs(glow.y - expectedY)).toBeLessThan(.03);
        expect(glow).toMatchObject({width: target.width, height: target.height, naturalWidth: target.width, naturalHeight: target.height,
          asset: `ambient-${index === 0 ? 'green' : 'blue'}-${mobile ? 'mobile' : 'desktop'}.svg`, alt: '', opacity: '1', backgroundImage: 'none'});
      }
      geometry.push({scene, width, height, sample});
    }
    expect(errors).toEqual([]);
    await writeFile(info.outputPath('canonical-glow-geometry.json'), JSON.stringify({geometry, isolatedRequests}, null, 2));
    await page.screenshot({path: info.outputPath('canonical-glow-mobile-page.png'), fullPage: true});
  });
}
