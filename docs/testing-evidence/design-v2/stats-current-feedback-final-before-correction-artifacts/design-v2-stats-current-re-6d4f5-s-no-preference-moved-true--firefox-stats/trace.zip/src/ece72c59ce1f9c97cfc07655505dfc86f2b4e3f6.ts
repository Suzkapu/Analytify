import {test,expect} from './fixtures';
import {mockSpotify,seedAuthenticatedBrowser,expectNoBlockingAxeViolations} from './helpers/authenticated-browser';

for(const motion of ['no-preference','reduce'] as const) for(const moveFocus of [false,true]) {
  test(`cached Stats failure preserves complete rows and recovers without duplicate requests or stolen focus (${motion}, moved=${moveFocus})`,async({page},info)=>{
    await page.clock.setFixedTime(new Date('2026-10-06T12:00:00Z'));await page.emulateMedia({reducedMotion:motion});
    await mockSpotify(page);await seedAuthenticatedBrowser(page);
    await page.evaluate(async()=>{
      await new Promise<void>((resolve,reject)=>{
        const request=indexedDB.open('AnalytifyDB',4);request.onerror=()=>reject(request.error);
        request.onsuccess=()=>{
          const db=request.result,tx=db.transaction(['featureData','appData'],'readwrite');
          for(const userId of ['e2e-user','e2e-user_dev']){
            const parts={tracks:[{id:'cached-song',name:'Cached song',artists:[{name:'Cached artist'}],album:{images:[]}}],
              artists:[{id:'cached-artist',name:'Cached artist',genres:['pop'],images:[]}],genres:[{name:'pop',count:1,percentage:100}]};
            for(const [part,value] of Object.entries(parts))tx.objectStore('featureData').put({key:`${userId}_stats_short_term_${part}`,value:JSON.stringify(value)});
            tx.objectStore('appData').put({key:`${userId}_stats_short_term_lastUpdated`,value:String(Date.now()-2*86400000)});
          }
          tx.oncomplete=()=>{db.close();resolve();};tx.onerror=()=>reject(tx.error);
        };
      });
    });
    let finishInitial!:()=>void,finishRetry!:()=>void;
    const initial=new Promise<void>(resolve=>finishInitial=resolve),retry=new Promise<void>(resolve=>finishRetry=resolve);
    let requests=0;
    await page.route('https://api.spotify.com/v1/me/top/artists?*',async route=>{
      requests++;
      if(requests===1){await initial;return route.fulfill({status:403,json:{error:{status:403,message:'Isolated stale-refresh failure'}}});}
      await retry;return route.fulfill({json:{items:[{id:'fresh-artist',name:'Fresh artist',genres:['pop'],images:[]}],total:1}});
    });
    await page.goto('/new/stats');const main=page.getByRole('main');
    await expect(main.getByText('Cached song',{exact:true})).toBeVisible();
    await expect(main.getByText('Refreshing this range… Your cached rankings stay visible.',{exact:true})).toBeVisible();
    expect(requests).toBe(1);await main.locator('.v2-page').screenshot({path:info.outputPath('cached-refreshing.png')});
    finishInitial();await expect(main.getByRole('alert')).toBeVisible();
    await expect(main.getByText('Cached song',{exact:true})).toBeVisible();
    await expect(main.getByText('Could not refresh this range',{exact:true})).toBeVisible();
    await expectNoBlockingAxeViolations(page);await main.locator('.v2-page').screenshot({path:info.outputPath('cached-refresh-failed.png')});
    await main.getByRole('button',{name:'Retry',exact:true}).press('Enter');
    await expect(main.getByText('Refreshing this range… Your cached rankings stay visible.',{exact:true})).toBeVisible();
    await expect(main.getByText('Cached song',{exact:true})).toBeVisible();
    await expect(main.locator('v2-current-stats-feedback section')).toBeFocused();
    await expect.poll(()=>requests).toBe(2);
    const search=main.getByRole('searchbox');if(moveFocus)await search.focus();
    finishRetry();await expect(main.getByText('Test Song',{exact:true})).toBeVisible();
    await expect(main.getByText('Cached song',{exact:true})).toHaveCount(0);await expect(main.getByRole('alert')).toHaveCount(0);
    expect(requests).toBe(2);
    if(moveFocus)await expect(search).toBeFocused();else await expect(main.getByRole('heading',{name:'Top songs',exact:true})).toBeFocused();
    await expectNoBlockingAxeViolations(page);
  });
}
